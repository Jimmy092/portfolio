public interface CreditCard {
}
