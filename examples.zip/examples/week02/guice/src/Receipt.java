public interface Receipt {
}
