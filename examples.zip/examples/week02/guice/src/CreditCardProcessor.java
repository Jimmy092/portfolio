interface CreditCardProcessor {
}
