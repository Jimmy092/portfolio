package j.factory;

public interface Shape {
    void draw();
}
