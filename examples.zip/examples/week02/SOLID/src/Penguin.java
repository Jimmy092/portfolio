public class Penguin extends Bird {
    public void fly() {
        throw new UnsupportedOperationException();
    }
}