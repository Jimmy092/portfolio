public class Parrot extends Bird {
    public void fly() { /* implementation */ }

    public void speak() { /* implementation */ }
}