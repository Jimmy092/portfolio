public interface TimerClient {
    public void timeout();
}