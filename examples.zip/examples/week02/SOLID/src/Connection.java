public interface Connection {
    public void dial(String pno);

    public void hangup();
}