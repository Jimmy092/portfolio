public abstract class Bird {
    public abstract void fly();
}