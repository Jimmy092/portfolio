public class Timer {
    public void register(int timeout,
                         TimerClient client) {
        /* implementation */
    }
}
