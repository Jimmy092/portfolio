public class Door {
    public void lock() { /* implementation */ }

    public void unlock() { /* implementation */ }

    public boolean isOpen() {
        return true; /* implementation */
    }
}