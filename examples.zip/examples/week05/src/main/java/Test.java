public class Test {
    public void doesNothing(){
        System.out.println("asdasd");
    }

    public int addOne(int x){
        return x + 1;
    }
}