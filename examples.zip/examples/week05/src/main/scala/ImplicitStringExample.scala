import implicitstring.utils._

object ImplicitStringExample extends App {
    println("HAL".increment)
    println("4".plusOne)
    println("0".asBoolean)
    println("1".asBoolean)
}
