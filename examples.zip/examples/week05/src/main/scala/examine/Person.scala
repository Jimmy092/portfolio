trait X
class Y() extends X
//class Person(name: String, age: Int)

//class Node[+A]()
