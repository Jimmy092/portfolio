//sealed trait MyTrait
//object MyObject
//final case class Thing() extends MyTrait

case class Person(name: String, age: Int)