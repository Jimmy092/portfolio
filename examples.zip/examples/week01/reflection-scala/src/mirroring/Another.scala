package mirroring

case class Another()
