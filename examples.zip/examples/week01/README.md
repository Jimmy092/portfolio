For Scala reflection use the Java reflection api as the Manifest approach has been deprecated and Mirroring, the new approach, is still in a state of flux.
