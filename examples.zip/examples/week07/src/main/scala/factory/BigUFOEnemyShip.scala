package factory

class BigUFOEnemyShip() extends UFOEnemyShip {
  setName("Big UFO Enemy Ship")
  setDamage(40.0)
}
