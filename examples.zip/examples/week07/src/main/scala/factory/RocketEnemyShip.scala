package factory

class RocketEnemyShip() extends EnemyShip {
  setName("Rocket Enemy Ship")
  setDamage(10.0)
}
