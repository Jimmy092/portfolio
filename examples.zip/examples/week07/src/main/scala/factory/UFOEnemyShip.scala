package factory

class UFOEnemyShip() extends EnemyShip {
  setName("UFO Enemy Ship")
  setDamage(20.0)
}
