package abstractfactory

case class UFOBossEnemyShip(// We define the type of ship we want to create
                       // by stating we want to use the factory that
                       // makes enemy ships
                       shipFactory: EnemyShipFactory)
  extends EnemyShip {
  // The enemy ship required parts list is sent to
  // this method. They state that the enemy ship
  // must have a weapon and engine assigned. That
  // object also states the specific parts needed
  // to make a Boss UFO versus a Regular UFO
  // EnemyShipBuilding calls this method to build a
  // specific UFOBossEnemyShip
  override def makeShip() {
    println("Making enemy ship " + getName)
    // The specific weapon & engine needed were passed in
    // shipFactory. We are assigning those specific part
    // objects to the UFOBossEnemyShip here
    weapon = shipFactory.addESGun
    engine = shipFactory.addESEngine
  }
}
