package command

object TVRemote {
  def getDevice: ElectronicDevice = Television()
}
