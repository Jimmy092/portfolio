package command

trait ElectronicDevice {
  def on()

  def off()

  def volumeUp()

  def volumenDown()
}
