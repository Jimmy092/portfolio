package mediator

case class StockOffer(var stockShares: Int, var stockSymbol: String, var colleagueCode: Int)
